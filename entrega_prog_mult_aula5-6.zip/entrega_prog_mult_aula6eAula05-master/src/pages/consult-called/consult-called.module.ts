import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConsultCalledPage } from './consult-called';

@NgModule({
  declarations: [
    ConsultCalledPage,
  ],
  imports: [
    IonicPageModule.forChild(ConsultCalledPage),
  ],
})
export class ConsultCalledPageModule {}
