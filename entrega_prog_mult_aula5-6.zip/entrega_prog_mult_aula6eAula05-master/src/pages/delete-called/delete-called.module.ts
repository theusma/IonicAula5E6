import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DeleteCalledPage } from './delete-called';

@NgModule({
  declarations: [
    DeleteCalledPage,
  ],
  imports: [
    IonicPageModule.forChild(DeleteCalledPage),
  ],
})
export class DeleteCalledPageModule {}
