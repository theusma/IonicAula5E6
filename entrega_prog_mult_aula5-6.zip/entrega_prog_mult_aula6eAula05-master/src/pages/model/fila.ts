

export interface Fila{ 
      
       nome: string;    
    }