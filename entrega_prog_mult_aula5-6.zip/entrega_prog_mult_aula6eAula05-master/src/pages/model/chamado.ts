import { Fila } from "./fila";

export interface Chamado{
    descricao: string;
    fila: Fila;  
 }